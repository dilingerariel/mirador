from django.contrib import admin
from .models import Residente

# Registra el modelo Residente en el panel de administración
admin.site.register(Residente)